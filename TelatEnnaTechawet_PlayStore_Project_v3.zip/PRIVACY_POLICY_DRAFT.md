# Privacy Policy – ተማር እና ተጫወት

Developer: Eliyas Gebru

ይህ ረቂቅ የPrivacy Policy ነው። የመጨረሻ ህትመት ከመደረጉ በፊት ከApp ውስጥ የሚሰበሰቡ/የማይሰበሰቡ መረጃዎች ጋር በትክክል መስማማቱ ይገምገም።

1. ይህ የመጀመሪያ ስሪት ስም፣ ኢሜይል፣ ስልክ ቁጥር ወይም ትክክለኛ አድራሻ አይጠይቅም።
2. ለማስተማር የApp ውስጥ ነጥብ/እድገት በመሣሪያው ላይ ብቻ ሊቀመጥ ይችላል።
3. የሶስተኛ ወገን ማስታወቂያ፣ analytics ወይም tracking SDK ካልተጨመረ የውጭ መረጃ መላክ አይኖርም።
4. ለህጻናት የሚመለከቱ የGoogle Play Families መስፈርቶች ይከበራሉ።
5. ጥያቄ ካለ የDeveloper የመገኛ ኢሜይል በPlay Console ውስጥ የሚገኝ እና በPublic Privacy Policy ላይ የሚገለጽ መሆን አለበት።
