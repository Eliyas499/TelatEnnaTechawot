plugins { id("com.android.application") }

android {
    namespace = "com.eliyagebru.telat"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.eliyagebru.telat"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
