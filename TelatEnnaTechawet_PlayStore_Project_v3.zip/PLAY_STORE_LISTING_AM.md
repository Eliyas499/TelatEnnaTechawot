# Google Play Store የማቅረቢያ መረጃ

**App name:** ተማር እና ተጫወት  
**Developer:** Eliyas Gebru  
**Package name:** com.eliyagebru.telat  
**Version:** 1.0  
**Target audience:** 3–5 ዓመት  
**Category:** Education

## Short description
ለ3–5 ዓመት ልጆች በጨዋታ ፊደላት፣ ቁጥሮች፣ ቀለማትና እንስሳትን ይማሩ።

## Full description
“ተማር እና ተጫወት” ለትንንሽ ልጆች መማርን ከመጫወት ጋር የሚያጣምር የትምህርት App ነው። ልጆች በቀላል ጨዋታዎች ፊደላት፣ ቁጥሮች፣ ቀለማትና እንስሳትን ይማራሉ። ትክክለኛ መልስ ሲሰጡ ነጥብ ያገኛሉ።

## Privacy
ይህ የመጀመሪያ ስሪት የልጆችን የግል መረጃ ለመሰብሰብ የተዘጋጀ አይደለም። ከመጨረሻ ህትመት በፊት የGoogle Play Data Safety መረጃ እና የተሟላ Privacy Policy በእውነተኛው የApp ባህሪ መሰረት መረጋገጥ አለበት።
