# ለGoogle Play ማቅረብ

1. Android Studio ይጫኑ እና ይህን project ይክፈቱ።
2. Gradle sync ያድርጉ።
3. Build > Generate Signed App Bundle / APK > Android App Bundle ይምረጡ።
4. Release keystore ይፍጠሩ እና የሚስጥር የkeystore ፋይል/የይለፍ ቃል በደህና ያስቀምጡ።
5. የሚፈጠረው .aab ፋይል በPlay Console ውስጥ ይጫኑ።
6. App content, Data safety, Target audience, Store listing ይሙሉ።
7. አዲስ personal developer account ከNov 13, 2023 በኋላ ከተፈጠረ የGoogle የtesting መስፈርቶችን ይከተሉ።
8. በ2026-08-31 ጀምሮ አዲስ Android apps ለGoogle Play መላክ Android 16 / API 36 ወይም ከዚያ በላይ target ማድረግ አለባቸው።


## Version 3 additions
- Added Android Text-to-Speech bridge for spoken learning prompts.
- The app does not request microphone, camera, location, contacts, or storage permissions.
- Speech uses the device's installed Android TTS engine/voice. Availability and language support depend on the device.
- For a production Play Store release, generate a signed Android App Bundle (.aab) and complete Play Console verification/testing.
